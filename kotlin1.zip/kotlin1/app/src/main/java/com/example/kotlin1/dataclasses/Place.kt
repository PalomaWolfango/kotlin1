package com.example.kotlin1.dataclasses

data class Place (val name: String, val habitants: Int, val capital: String)